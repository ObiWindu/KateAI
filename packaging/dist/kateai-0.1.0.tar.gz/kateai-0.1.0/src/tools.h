/*
 * SPDX-FileCopyrightText: 2026 ObiWindu <Obi.wandu@proton.me>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include "documentbridge.h"
#include "graph/projectgraph.h"
#include "permissions.h"
#include "sandbox.h"
#include "types.h"

#include <QObject>

namespace KateAi
{

class ToolRunner : public QObject
{
    Q_OBJECT

public:
    ToolRunner(Sandbox sandbox, DocumentBridge *bridge, QObject *parent = nullptr);

    void setSandbox(Sandbox sandbox)
    {
        m_sandbox = std::move(sandbox);
    }
    void setTimeoutMs(int timeoutMs)
    {
        m_timeoutMs = timeoutMs;
    }
    void setProjectGraph(ProjectGraph *graph)
    {
        m_projectGraph = graph;
    }

    ToolResult run(const ToolCall &call);
    PermissionRequest describe(const ToolCall &call) const;

Q_SIGNALS:
    void bashFinished(const ToolResult &result);

private:
    ToolResult readFile(const QJsonObject &args) const;
    ToolResult writeFile(const QJsonObject &args);
    ToolResult editFile(const QJsonObject &args);
    ToolResult multiEditFile(const QJsonObject &args);
    ToolResult listDir(const QJsonObject &args) const;
    ToolResult grep(const QJsonObject &args) const;
    ToolResult glob(const QJsonObject &args) const;
    ToolResult bash(const QJsonObject &args);
    ToolResult queryProjectGraph(const QJsonObject &args) const;

    Sandbox m_sandbox;
    DocumentBridge *m_bridge = nullptr;
    ProjectGraph *m_projectGraph = nullptr;
    int m_timeoutMs = 60000;
};

QString unifiedDiff(const QString &path, const QString &before, const QString &after);
QString shellCommandFor(const QString &toolName, const QJsonObject &args);

} // namespace KateAi
