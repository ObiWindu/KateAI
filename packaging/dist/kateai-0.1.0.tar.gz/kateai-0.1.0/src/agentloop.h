/*
 * SPDX-FileCopyrightText: 2026 ObiWindu <Obi.wandu@proton.me>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include "documentbridge.h"
#include "llmclient.h"
#include "permissions.h"
#include "sandbox.h"
#include "sessionstore.h"
#include "tools.h"
#include "types.h"
#include "graph/projectgraph.h"

#include <QObject>
#include <QQueue>
#include <QSet>
#include <QHash>
#include <QTimer>
#include <memory>

namespace KateAi
{

class AgentLoop : public QObject
{
    Q_OBJECT

public:
    explicit AgentLoop(QObject *parent = nullptr);

    void setSettings(const Settings &settings);
    void setWorkspace(const QString &workspace);
    void setDocumentBridge(DocumentBridge *bridge);
    void setEditorContext(const QString &context);

    void updateProjectGraph(const QString &filePath, const QString &content);
    ProjectGraph *getProjectGraph() const { return m_projectGraph.get(); }
    QList<GraphNode *> getProjectNodes() const;
    QList<GraphEdge *> getProjectEdges() const;

    bool isBusy() const { return m_busy; }

    LlmClient *client() { return &m_client; }
    DocumentBridge *documentBridge() { return m_bridge; }

    void start(const QString &userText);
    void abort();
    void resetConversation();
    void resolvePermission(PermissionDecision decision);
    void fetchModels(Provider provider);

    const QList<ChatMessage> &messages() const { return m_messages; }

    // Session persistence
    SessionStore::SessionData sessionData() const;
    void restoreSession(const SessionStore::SessionData &data);
    void clearSession();

    PermissionPolicy &policy() { return m_policy; }

Q_SIGNALS:
    void userMessage(const QString &text);
    void assistantDelta(const QString &delta);
    void thinkingDelta(const QString &delta);
    void thinkingFinished(const QString &text);
    void assistantFinished(const QString &text);
    void planUpdated(const QJsonArray &plan);
    void toolStarted(const PermissionRequest &request);
    void toolFinished(const ToolResult &result);
    void permissionNeeded(const PermissionRequest &request);
    void statusChanged(const QString &status);
    void activityUpdated(const QString &text);
    void failed(const QString &error);
    void turnFinished();
    void modelsReceived(Provider provider, const QStringList &models);
    void modelsFailed(Provider provider, const QString &error);

private:
    enum class State {
        Idle,
        WaitingForNextModel,
        WaitingForModel,
        ExecutingTools,
        WaitingForPermission,
    };

    void scheduleNextModelStep();
    void sendToModel();
    void finishTurn();
    void finishWithFailure(const QString &error);
    bool canStartModelRequest(QString *error = nullptr) const;
    QString actionSignature(const ToolCall &call) const;
    bool isRepeatSensitiveTool(const QString &toolName) const;
    void appendControllerMessage(const QString &content);
    QString formatToolResult(const ToolCall &call, const ToolResult &result) const;
    QString describePlannedWork(const QList<ToolCall> &calls) const;
    QString summarizeCompletedWork() const;
    bool isMutationTool(const QString &toolName) const;
    bool isVerificationTool(const QString &toolName) const;
    bool isVerificationForChangedFiles(const ToolCall &call) const;
    void appendToolResult(const ToolCall &call, ToolResult result);
    void appendToolResultsToConversation();
    void addBudgetFailureResults(const QString &reason);
    void requestVerificationTurn();
    void emitPlanUpdate();
    void onFinished(const QString &text, const QList<ToolCall> &toolCalls);
    void onFailed(const QString &error);
    void processQueue();
    void executeOne(const ToolCall &call);
    QString systemPrompt() const;
    QList<ToolCall> bundleSimilarTools(const QList<ToolCall> &calls);

    Settings m_settings;
    QString m_workspace;
    QString m_editorContext;
    DocumentBridge *m_bridge = nullptr;
    LlmClient m_client;
    PermissionPolicy m_policy;
    std::unique_ptr<Sandbox> m_sandbox;
    std::unique_ptr<ToolRunner> m_tools;
    std::unique_ptr<ProjectGraph> m_projectGraph;

    QList<ChatMessage> m_messages;
    QList<ToolCall> m_queue;
    QList<ToolResult> m_pendingResults;
    ToolCall m_waitingCall;
    PermissionRequest m_waitingRequest;

    bool m_busy = false;
    State m_state = State::Idle;
    int m_modelRequests = 0;
    int m_toolCalls = 0;
    QQueue<qint64> m_modelRequestTimes;
    QTimer m_nextModelTimer;

    quint64 m_stateEpoch = 0;
    QSet<QString> m_actionSignatures;
    QHash<QString, int> m_actionRepeatCounts;
    QSet<QString> m_actionsThisModelTurn;
    int m_recoveryPromptCount = 0;
    QSet<QString> m_changedPaths;
    bool m_changesNeedVerification = false;
    bool m_verificationAttempted = false;
    int m_verificationPromptCount = 0;

    // Hidden reasoning and structured plan for the current turn.
    QString m_currentThinking;
    QJsonArray m_currentPlan;
    bool m_planShown = false;
    bool m_thinkingFinishedEmitted = false;

    QString m_currentAssistant;
};

} // namespace KateAi
