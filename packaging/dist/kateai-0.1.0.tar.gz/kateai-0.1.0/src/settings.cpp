/*
 * SPDX-FileCopyrightText: 2026 ObiWindu <Obi.wandu@proton.me>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#include "settings.h"

#include <KConfigGroup>
#include <KSharedConfig>

using namespace Qt::Literals::StringLiterals;

namespace KateAi
{

static KConfigGroup group()
{
    return KConfigGroup(KSharedConfig::openConfig(), u"KateAI"_s);
}

Settings SettingsStore::load()
{
    const KConfigGroup g = group();
    Settings s;
    s.provider = providerFromId(g.readEntry(u"Provider"_s, providerId(Provider::Grok)));
    s.grokApiKey = g.readEntry(u"GrokApiKey"_s, QString());
    s.openaiApiKey = g.readEntry(u"OpenAIApiKey"_s, QString());
    s.openrouterApiKey = g.readEntry(u"OpenRouterApiKey"_s, QString());
    s.deepseekApiKey = g.readEntry(u"DeepSeekApiKey"_s, QString());
    s.acpApiKey = g.readEntry(u"AcpApiKey"_s, QString());
    s.grokModel = g.readEntry(u"GrokModel"_s, u"grok-4.5"_s);
    s.openaiModel = g.readEntry(u"OpenAIModel"_s, u"gpt-4.1"_s);
    s.openrouterModel = g.readEntry(u"OpenRouterModel"_s, u"x-ai/grok-4"_s);
    s.deepseekModel = g.readEntry(u"DeepSeekModel"_s, u"deepseek-flash"_s);
    s.acpModel = g.readEntry(u"AcpModel"_s, u"acp-agent"_s);
    s.deepseekUrl = g.readEntry(u"DeepSeekUrl"_s, u"https://api.deepseek.com"_s);
    s.acpUrl = g.readEntry(u"AcpUrl"_s, u"http://localhost:8080"_s);
    s.apiFormat = apiFormatFromId(g.readEntry(u"ApiFormat"_s, apiFormatId(ApiFormat::OpenAICompatible)));
    s.permissionMode = permissionModeFromId(g.readEntry(u"PermissionMode"_s, permissionModeId(PermissionMode::Ask)));
    s.sandbox = sandboxProfileFromId(g.readEntry(u"Sandbox"_s, sandboxProfileId(SandboxProfile::Workspace)));
    const int legacyMaxIterations = g.readEntry(u"MaxIterations"_s, 20);
    s.maxModelRequests = g.readEntry(u"MaxModelRequests"_s, 40);
    s.maxToolCalls = g.readEntry(u"MaxToolCalls"_s, legacyMaxIterations);
    s.requestsPerMinute = g.readEntry(u"RequestsPerMinute"_s, 15);
    s.maxIterations = legacyMaxIterations;
    s.bashTimeoutMs = g.readEntry(u"BashTimeoutMs"_s, 60000);
    s.planMode = g.readEntry(u"PlanMode"_s, false);
    s.loadProjectInstructions = g.readEntry(u"LoadProjectInstructions"_s, true);
    s.thinkingMode = g.readEntry(u"ThinkingMode"_s, true);
    s.extraSystemPrompt = g.readEntry(u"ExtraSystemPrompt"_s, QString());
    s.extraDenyGlobs = g.readEntry(u"ExtraDenyGlobs"_s, QStringList());
    s.contextCompressionLevel = g.readEntry(u"ContextCompressionLevel"_s, 1);
    s.maxGraphNodes = g.readEntry(u"MaxGraphNodes"_s, 50);
    s.maxGraphEdges = g.readEntry(u"MaxGraphEdges"_s, 100);
    s.compressProjectGraph = g.readEntry(u"CompressProjectGraph"_s, true);
    s.includeFileContents = g.readEntry(u"IncludeFileContents"_s, true);
    s.maxFileContentLength = g.readEntry(u"MaxFileContentLength"_s, 500);
    s.compressEditorContext = g.readEntry(u"CompressEditorContext"_s, true);
    s.maxEditorContextLength = g.readEntry(u"MaxEditorContextLength"_s, 200);
    s.compressProjectInstructions = g.readEntry(u"CompressProjectInstructions"_s, true);
    s.maxProjectInstructionsLength = g.readEntry(u"MaxProjectInstructionsLength"_s, 2048);
    s.compressSystemPrompt = g.readEntry(u"CompressSystemPrompt"_s, true);
    s.maxSystemPromptLength = g.readEntry(u"MaxSystemPromptLength"_s, 1024);
    // Optimal Intelligence Parameters
    s.temperature = g.readEntry(u"Temperature"_s, 0.2);
    s.topP = g.readEntry(u"TopP"_s, 0.95);
    s.maxTokens = g.readEntry(u"MaxTokens"_s, 0);
    s.reasoningEffort = g.readEntry(u"ReasoningEffort"_s, QString());
    s.selfCritique = g.readEntry(u"SelfCritique"_s, true);
    s.parallelToolCalls = g.readEntry(u"ParallelToolCalls"_s, true);
    s.verbosity = g.readEntry(u"Verbosity"_s, 1);
    s.autoCollapseThinking = g.readEntry(u"AutoCollapseThinking"_s, false);
    s.maxSavedConversations = g.readEntry(u"MaxSavedConversations"_s, 50);
    s.maxExpandedToolCards = g.readEntry(u"MaxExpandedToolCards"_s, 10);
    if (s.maxModelRequests < 1) {
        s.maxModelRequests = 1;
    }
    if (s.maxToolCalls < 1) {
        s.maxToolCalls = 1;
    }
    if (s.requestsPerMinute < 1) {
        s.requestsPerMinute = 1;
    }
    if (s.requestsPerMinute > 60) {
        s.requestsPerMinute = 60;
    }
    // Keep the legacy field coherent for older callers.
    s.maxIterations = s.maxToolCalls;
    if (s.bashTimeoutMs < 1000) {
        s.bashTimeoutMs = 1000;
    }
    return s;
}

void SettingsStore::save(const Settings &settings)
{
    KConfigGroup g = group();
    g.writeEntry(u"Provider"_s, providerId(settings.provider));
    g.writeEntry(u"GrokApiKey"_s, settings.grokApiKey);
    g.writeEntry(u"OpenAIApiKey"_s, settings.openaiApiKey);
    g.writeEntry(u"OpenRouterApiKey"_s, settings.openrouterApiKey);
    g.writeEntry(u"DeepSeekApiKey"_s, settings.deepseekApiKey);
    g.writeEntry(u"AcpApiKey"_s, settings.acpApiKey);
    g.writeEntry(u"GrokModel"_s, settings.grokModel);
    g.writeEntry(u"OpenAIModel"_s, settings.openaiModel);
    g.writeEntry(u"OpenRouterModel"_s, settings.openrouterModel);
    g.writeEntry(u"DeepSeekModel"_s, settings.deepseekModel);
    g.writeEntry(u"AcpModel"_s, settings.acpModel);
    g.writeEntry(u"DeepSeekUrl"_s, settings.deepseekUrl);
    g.writeEntry(u"AcpUrl"_s, settings.acpUrl);
    g.writeEntry(u"ApiFormat"_s, apiFormatId(settings.apiFormat));
    g.writeEntry(u"PermissionMode"_s, permissionModeId(settings.permissionMode));
    g.writeEntry(u"Sandbox"_s, sandboxProfileId(settings.sandbox));
    g.writeEntry(u"MaxModelRequests"_s, settings.maxModelRequests);
    g.writeEntry(u"MaxToolCalls"_s, settings.maxToolCalls);
    g.writeEntry(u"RequestsPerMinute"_s, settings.requestsPerMinute);
    // Preserve the old key for existing versions/UI.
    g.writeEntry(u"MaxIterations"_s, settings.maxToolCalls);
    g.writeEntry(u"BashTimeoutMs"_s, settings.bashTimeoutMs);
    g.writeEntry(u"PlanMode"_s, settings.planMode);
    g.writeEntry(u"LoadProjectInstructions"_s, settings.loadProjectInstructions);
    g.writeEntry(u"ThinkingMode"_s, settings.thinkingMode);
    g.writeEntry(u"ExtraSystemPrompt"_s, settings.extraSystemPrompt);
    g.writeEntry(u"ExtraDenyGlobs"_s, settings.extraDenyGlobs);
    
    // Save context compression settings
    g.writeEntry(u"ContextCompressionLevel"_s, settings.contextCompressionLevel);
    g.writeEntry(u"MaxGraphNodes"_s, settings.maxGraphNodes);
    g.writeEntry(u"MaxGraphEdges"_s, settings.maxGraphEdges);
    g.writeEntry(u"CompressProjectGraph"_s, settings.compressProjectGraph);
    g.writeEntry(u"IncludeFileContents"_s, settings.includeFileContents);
    g.writeEntry(u"MaxFileContentLength"_s, settings.maxFileContentLength);
    g.writeEntry(u"CompressEditorContext"_s, settings.compressEditorContext);
    g.writeEntry(u"MaxEditorContextLength"_s, settings.maxEditorContextLength);
    g.writeEntry(u"CompressProjectInstructions"_s, settings.compressProjectInstructions);
    g.writeEntry(u"MaxProjectInstructionsLength"_s, settings.maxProjectInstructionsLength);
    g.writeEntry(u"CompressSystemPrompt"_s, settings.compressSystemPrompt);
    g.writeEntry(u"MaxSystemPromptLength"_s, settings.maxSystemPromptLength);
    // Save optimal intelligence parameters
    g.writeEntry(u"Temperature"_s, settings.temperature);
    g.writeEntry(u"TopP"_s, settings.topP);
    g.writeEntry(u"MaxTokens"_s, settings.maxTokens);
    g.writeEntry(u"ReasoningEffort"_s, settings.reasoningEffort);
    g.writeEntry(u"SelfCritique"_s, settings.selfCritique);
    g.writeEntry(u"ParallelToolCalls"_s, settings.parallelToolCalls);
    g.writeEntry(u"Verbosity"_s, settings.verbosity);
    g.writeEntry(u"AutoCollapseThinking"_s, settings.autoCollapseThinking);
    g.writeEntry(u"MaxSavedConversations"_s, settings.maxSavedConversations);
    g.writeEntry(u"MaxExpandedToolCards"_s, settings.maxExpandedToolCards);
    
    g.sync();
}

} // namespace KateAi
